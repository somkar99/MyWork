package com.example.admin.h2hpartner.UI

import android.app.Activity
import android.os.Bundle
import com.example.admin.h2hpartner.R

/**
 * Created by apple on 13/03/18.
 */
class Splash0 : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.splash_extended0)

    }
}