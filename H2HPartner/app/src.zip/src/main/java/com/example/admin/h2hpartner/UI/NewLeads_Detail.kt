package com.example.admin.h2hpartner.UI

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v7.widget.CardView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import com.beust.klaxon.Parser
import com.example.admin.h2hpartner.Adapter.NewLeads_QandA_Adapter
import com.example.admin.h2hpartner.BaseActivity
import com.example.admin.h2hpartner.Model.QueAnsModel
import com.example.admin.h2hpartner.R
import com.example.admin.h2hpartner.Services.CustomServices
import com.example.admin.h2hpartner.Services.StaticRefs
import com.example.admin.h2hpartner.Services.TransperantProgressDialog
import com.example.admin.h2hpartner.prefs
import com.github.kittinunf.fuel.Fuel
import com.github.kittinunf.fuel.android.extension.responseJson
import com.sdsmdg.tastytoast.TastyToast
import kotlinx.android.synthetic.main.footer.*
import kotlinx.android.synthetic.main.newlead_detail.*
import org.json.JSONObject
import java.text.SimpleDateFormat


class NewLeads_Detail : BaseActivity() {
    override lateinit var context: Context
    override lateinit var activity: Activity
    lateinit var pd: TransperantProgressDialog
    lateinit var llm: LinearLayoutManager
    lateinit var rcvAdapter: RecyclerView.Adapter<NewLeads_QandA_Adapter.ViewHolder>
    var adapter: NewLeads_QandA_Adapter? = null
    var lsTransaction: Int? = null
    lateinit var lsMobile:String
    var lsMessage = ""
    var lsRejectionReason = ""
    var lsStatus = ""
    var lscasestatus=""
    var Key:String?=""
     var cust_id: String?=""


    lateinit var alertdialog: android.support.v7.app.AlertDialog


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.newlead_detail)

        hideFooter(true)

        context = this
        activity = this

        initlayout()
        showDetails()

    }


    override fun onResume() {
        super.onResume()

        cust_id = getIntent().getStringExtra(StaticRefs.CUST_ID)

        Key = getIntent().getStringExtra("key")

        if(Key.equals("Leads")){
            setTitle("Leads Details")
            cbStartService.visibility=View.GONE

        }
        else if(Key.equals("Cases"))
        {
            lscasestatus = getIntent().getStringExtra("status")

            setTitle("My Cases")
            llacceptreject.visibility=View.GONE
            llButtons.visibility=View.GONE
            if(lscasestatus.equals(MyCases.HIRED)){
                cbStartService.visibility=View.VISIBLE

            }
        }
    }

    fun initlayout() {

        pd = TransperantProgressDialog(context)
        lsTransaction = getIntent().getIntExtra(StaticRefs.TRANSACTIONID,0)

        ivLeads.isEnabled = false
        tvLeads.isEnabled = false

        llm = LinearLayoutManager(this);
        rcvQueAns.layoutManager = llm;

        tvCall.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + lsMobile))
            startActivity(intent)

        }
        cbAccept.setOnClickListener {
            lsStatus=MyCases.ACCEPTED
            updateTransactionStatus()
        }
        cbReject.setOnClickListener {
            lsStatus=MyCases.REJECTED
            rejectionReasonPopup()
        }
        cbStartService.setOnClickListener {
            lsStatus=MyCases.ONGOING
            updateTransactionStatus()
        }
        cbMessage.setOnClickListener {
            val transactionid=1
            val i = Intent(context, Message::class.java)
            i.putExtra(StaticRefs.CUST_ID, cust_id)
            i.putExtra(StaticRefs.TRANSACTIONID, transactionid)
            startActivity(i)
        }

    }

    fun showDetails() {
        Fuel.post(StaticRefs.NEWLEADS_DETAILED, listOf((StaticRefs.TOKEN to prefs.token), (StaticRefs.TRANSACTIONID1 to lsTransaction)))
                .responseJson()
                { request,
                  response,
                  result ->
                    result.fold({ d ->
                        parseJson(result.get().content)
                        pd.dismiss()
                    }, { err ->
                        pd.dismiss()
                        TastyToast.makeText(context, "Internet Network Down", TastyToast.LENGTH_LONG, TastyToast.ERROR)
                    })
                }
    }

    fun parseJson(data: String) {
        val json = JSONObject(data)
        val response = json.getString(StaticRefs.DATA)
        val response1 = JSONObject(response)
        val response2 = response1.getString(StaticRefs.QUESTION_ANSWER)

        var lsFName = response1.getString(StaticRefs.CUSTOMERFIRSTNAME)
        var lsLName = response1.getString(StaticRefs.CUSTOMERLASTNAME)
        var lsServiceName = response1.getString(StaticRefs.SERVICENAME)
        var lsTypeName = response1.getString(StaticRefs.SERVICETYPENAME)
        var lsDate = response1.getString(StaticRefs.SERV_PLANNERDATE)
        var lsTime = response1.getString(StaticRefs.SERV_PLANNERTIME)
        lsMobile = response1.getString(StaticRefs.MOBILENO)
        // var lsDistance = response1.getString(StaticRefs.CUSTOMERLASTNAME)
        var lsLocation = response1.getString(StaticRefs.ADDRESSLINE1) + ", " + response1.getString(StaticRefs.ADDRESSLINE2) + ", " + response1.getString(StaticRefs.CITY) + ", " + response1.getString(StaticRefs.STATE) + ", " + response1.getString(StaticRefs.PINCODE)

        tvName.setText("$lsFName $lsLName")
        tvServiceAsked.setText("$lsServiceName $lsTypeName")
        tvLocation.setText(lsLocation)
        tvDate.setText(getDate(lsDate))

        val parser = Parser()
        val stringBuilder = StringBuilder(response2)
        val model = parser.parse(stringBuilder) as JsonArray<JsonObject>
        val new = model.map { QueAnsModel(it) }.filterNotNull();

        adapter = NewLeads_QandA_Adapter(new);
        rcvAdapter = adapter!!
        rcvQueAns.adapter = rcvAdapter;
        rcvAdapter.notifyDataSetChanged();

    }

    fun rejectionReasonPopup(){
        var Reason:String?=null
        val layoutInflater = LayoutInflater.from(this)
        val dialogview = layoutInflater.inflate(R.layout.newlead_rejection_dialog, null)

        val etOtherreason = dialogview.findViewById<EditText>(R.id.etOtherReason)
        val cvOtherreason = dialogview.findViewById<CardView>(R.id.cvOtherreason)

        val ivBusyChecked = dialogview.findViewById<ImageView>(R.id.ivBusyChecked)
        val ivBusyUnChecked = dialogview.findViewById<ImageView>(R.id.ivBusyUnChecked)
        val tvBusy = dialogview.findViewById<TextView>(R.id.tvBusy)

        val ivFarChecked = dialogview.findViewById<ImageView>(R.id.ivLocationFarChecked)
        val ivFarUnChecked = dialogview.findViewById<ImageView>(R.id.ivLocationFarUnChecked)
        val tvFar = dialogview.findViewById<TextView>(R.id.tvFar)

        val ivDontChecked = dialogview.findViewById<ImageView>(R.id.ivDontProvideChecked)
        val ivDontUnChecked = dialogview.findViewById<ImageView>(R.id.ivDontProvideUnChecked)
        val tvDontProvide = dialogview.findViewById<TextView>(R.id.tvDontProvide)

        val ivOtherChecked = dialogview.findViewById<ImageView>(R.id.ivOtherChecked)
        val ivOtherUnChecked = dialogview.findViewById<ImageView>(R.id.ivOtherUnChecked)
        val tvOther = dialogview.findViewById<TextView>(R.id.tvOther)


        val cbSubmit = dialogview.findViewById<Button>(R.id.cbReasonSubmit)


        val popup1 = android.support.v7.app.AlertDialog.Builder(this)
        popup1.setView(dialogview)

        alertdialog = popup1.create()

        alertdialog.show()

        ivBusyChecked.setOnClickListener {
            ivBusyUnChecked.visibility = View.VISIBLE
            ivBusyChecked.visibility = View.GONE
        }
        ivBusyUnChecked.setOnClickListener {
            ivBusyUnChecked.visibility = View.GONE
            ivBusyChecked.visibility = View.VISIBLE

        }

        ivFarChecked.setOnClickListener {
            ivFarUnChecked.visibility = View.VISIBLE
            ivFarChecked.visibility = View.GONE
        }
        ivFarUnChecked.setOnClickListener {
            ivFarUnChecked.visibility = View.GONE
            ivFarChecked.visibility = View.VISIBLE

        }

        ivDontChecked.setOnClickListener {
            ivDontUnChecked.visibility = View.VISIBLE
            ivDontChecked.visibility = View.GONE
        }
        ivDontUnChecked.setOnClickListener {
            ivDontUnChecked.visibility = View.GONE
            ivDontChecked.visibility = View.VISIBLE

        }

        ivOtherChecked.setOnClickListener {
            ivOtherUnChecked.visibility = View.VISIBLE
            ivOtherChecked.visibility = View.GONE
            cvOtherreason.visibility=View.GONE
            CustomServices.hideKB(alertdialog)
        }
        ivOtherUnChecked.setOnClickListener {
            ivOtherUnChecked.visibility = View.GONE
            ivOtherChecked.visibility = View.VISIBLE
            cvOtherreason.visibility=View.VISIBLE

        }

        cbSubmit.setOnClickListener {
            if(ivBusyChecked.visibility==View.VISIBLE){
                genMessage(tvBusy.text.toString())
            }
            if(ivFarChecked.visibility==View.VISIBLE){
                genMessage(tvFar.text.toString())
            }
            if(ivDontChecked.visibility==View.VISIBLE){
                genMessage(tvDontProvide.text.toString())
            }
            if(ivOtherChecked.visibility==View.VISIBLE){
                genMessage(etOtherreason.text.toString())
            }

            if(lsMessage.length>0){

                lsRejectionReason=lsMessage
                TastyToast.makeText(context,lsRejectionReason,TastyToast.LENGTH_SHORT,TastyToast.SUCCESS).show()
                alertdialog.dismiss()
                updateTransactionStatus()

            }
            else{
                TastyToast.makeText(context,"Please Select Rejection Reason",TastyToast.LENGTH_SHORT,TastyToast.WARNING).show()
            }
        }

    }

    fun genMessage(msg: String) {
        if (lsMessage.length > 0) {
            lsMessage = lsMessage + ", " + msg;
        } else {
            lsMessage = lsMessage + " " + msg;
        }
    }
    fun updateTransactionStatus(){

        if(lsStatus.equals(MyCases.ACCEPTED)||lsStatus.equals(MyCases.ONGOING)) {

            Fuel.post(StaticRefs.UPDATETRASCTIONSTATUS, listOf(StaticRefs.TOKEN to prefs.token, (StaticRefs.LEAD_SERVICEPROVIDERID to prefs.vendorid),
                    (StaticRefs.TRANSACTIONID to lsTransaction.toString()),(StaticRefs.LEADSTATUS to lsStatus)))
                    .responseJson()
                    { request,
                      response,
                      result ->
                        result.fold({ d ->
                            pd.show()
                            parseUpdateTransactionStatus(result.get().content)
                        }, { err ->
                            TastyToast.makeText(context, "Internet Network Down", TastyToast.LENGTH_LONG, TastyToast.ERROR)
                            //do something with error
                        })


                    }
        }
        else if(lsStatus.equals(MyCases.REJECTED)){

            Fuel.post(StaticRefs.UPDATETRASCTIONSTATUS, listOf(StaticRefs.TOKEN to prefs.token, (StaticRefs.LEAD_SERVICEPROVIDERID to prefs.vendorid),
                    (StaticRefs.TRANSACTIONID to lsTransaction.toString()),(StaticRefs.LEADSTATUS to lsStatus),
                    (StaticRefs.REJECTIONREASON to lsRejectionReason)))
                    .responseJson()
                    { request,
                      response,
                      result ->
                        result.fold({ d ->
                            pd.show()
                            parseUpdateTransactionStatus(result.get().content)
                        }, { err ->
                            TastyToast.makeText(context, "Internet Network Down", TastyToast.LENGTH_LONG, TastyToast.ERROR)
                            //do something with error
                        })


                    }

        }
    }
    fun parseUpdateTransactionStatus(response: String){
        pd.dismiss()
        val json = JSONObject(response)
        if (json.has(StaticRefs.STATUS) && json.getString(StaticRefs.STATUS) != null) {

            var message = ""
            if (json.has(StaticRefs.MESSAGE) && json.getString(StaticRefs.MESSAGE) != null) {
                message = json.getString(StaticRefs.MESSAGE)
            }
            if (json.getString(StaticRefs.STATUS).equals(StaticRefs.FAILED)) {

                TastyToast.makeText(this, message, Toast.LENGTH_LONG,TastyToast.ERROR).show()
            }
            else if(json.getString(StaticRefs.STATUS).equals(StaticRefs.SUCCESS)){
                pd.dismiss()
                finish()
                TastyToast.makeText(context, message, TastyToast.LENGTH_LONG,TastyToast.SUCCESS).show()
            }

        }

    }
    private fun getDate(lsVal: String):String {
        val fmt = "yyyy-MM-dd"
        val df = SimpleDateFormat(fmt)
        val dt = df.parse(lsVal)
        val dfmt = SimpleDateFormat("dd/MM/yyyy")
        val dateOnly = dfmt.format(dt)
        return dateOnly
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}


