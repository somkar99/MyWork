package com.example.admin.h2hpartner.UI

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.RadioGroup
import android.widget.Toast
import com.example.admin.h2hpartner.BaseActivity
import com.example.admin.h2hpartner.R
import com.example.admin.h2hpartner.Services.StaticRefs
import com.example.admin.h2hpartner.Services.TransperantProgressDialog
import com.example.admin.h2hpartner.prefs
import com.github.kittinunf.fuel.Fuel
import com.github.kittinunf.fuel.android.extension.responseJson
import com.sdsmdg.tastytoast.TastyToast
import kotlinx.android.synthetic.main.account_setting.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

class AccountSetting : BaseActivity() {

    override lateinit var context: Context
    override lateinit var activity: Activity
    lateinit var language: String
    var text: String = ""
    lateinit var pd: TransperantProgressDialog


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.account_setting)
        setTitle("Account Settings")
        hideFooter(true)

        context = this
        activity = this

        pd = TransperantProgressDialog(context)

        getData()

    }

    override fun onBackPressed() {
       super.onBackPressed()

        saveData()
    }

    fun saveData() {

        if (rbEnglish.isChecked) {
            text = "EN"
        } else if (rbHindi.isChecked) {
            text = "HI"
        } else if (rbMarathi.isChecked) {
            text = "MA"
        }
        TastyToast.makeText(context, text, TastyToast.LENGTH_LONG, TastyToast.SUCCESS)

        Fuel.post(StaticRefs.VENDOREDIT, listOf(StaticRefs.VENDORID to prefs.vendorid, (StaticRefs.VENDORUPDATEDBY to prefs.mobile_no),
                (StaticRefs.LANGUAGEPREFERENCE to text)))
                .responseJson() { request,
                                  response,
                                  result ->
                    result.fold({ d ->
                        parseJsonSave(result.get().content)
                    }, { err ->
                        TastyToast.makeText(context, "Internet Network Down", TastyToast.LENGTH_LONG, TastyToast.ERROR)
                    })
                }
    }

    fun parseJsonSave(response: String) {

        val json = JSONObject(response)
        if (json.has(StaticRefs.STATUS) && json.getString(StaticRefs.STATUS) != null) {

            var message = ""
            if (json.has(StaticRefs.MESSAGE) && json.getString(StaticRefs.MESSAGE) != null) {
                message = json.getString(StaticRefs.MESSAGE)
            }
            if (json.getString(StaticRefs.STATUS).equals(StaticRefs.FAILED)) {
                TastyToast.makeText(this, message, Toast.LENGTH_LONG, TastyToast.ERROR).show()
            } else if (json.getString(StaticRefs.STATUS).equals(StaticRefs.SUCCESS)) {
                prefs.language = text
                finish()
                TastyToast.makeText(context, message, TastyToast.LENGTH_LONG, TastyToast.SUCCESS).show()
            }

        }
    }

    fun showdata(language: String) {

        if (language.equals("EN")) rbEnglish.isChecked = true
        else if (language.equals("HI")) rbHindi.isChecked = true
        else if (language.equals("MA")) rbMarathi.isChecked = true
        else if (language.equals("")) rbEnglish.isChecked = true

    }

    fun getData() {
        pd.show()
        Fuel.post(StaticRefs.VENDORDETAILSURL, listOf((StaticRefs.VENDORID to prefs.vendorid), StaticRefs.TOKEN to prefs.token))
                .responseJson()
                { request,
                  response,
                  result ->
                    result.fold({ d ->
                        //do something with data

                        parseProfile(result.get().content)

                    }, { err ->
                        TastyToast.makeText(context, "Internet Network Down", TastyToast.LENGTH_LONG, TastyToast.ERROR)
                        //do something with error
                    })
                }
    }

    fun parseProfile(response: String) {
        pd.dismiss()
        var jsonob: JSONObject? = null

        if (response.contains(StaticRefs.DATA) && !StaticRefs.USERNAME.equals(null)) {
            val json = JSONObject(response)
            val data = json.getJSONObject(StaticRefs.DATA)
            language = data.getString(StaticRefs.LANGUAGEPREFERENCE)

            showdata(language)

        } else {
            pd.dismiss()
            TastyToast.makeText(context, "No Records Found ", TastyToast.LENGTH_LONG, TastyToast.WARNING).show()
        }
    }

}



