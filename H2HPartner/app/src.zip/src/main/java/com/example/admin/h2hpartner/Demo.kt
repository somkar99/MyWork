package com.example.admin.h2hpartner

import android.app.Activity
import android.os.Bundle

/**
 * Created by Admin on 06-02-18.
 */
class Demo : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.business)
    }
}