package com.example.admin.h2hpartner.Adapter

import android.content.Context
import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.admin.h2hpartner.Model.NewLeads_Model
import com.example.admin.h2hpartner.R
import java.lang.Long
import java.text.SimpleDateFormat
import java.util.*


class NewLeads_Adapter(dataSet: List<NewLeads_Model>) : RecyclerView.Adapter<NewLeads_Adapter.ViewHolder>() {
    val dataSet: List<NewLeads_Model> = dataSet
    //  var onClick: (View) -> Unit = {}
    lateinit var context: Context
    var lsFullname:String?=null
    var lsLocation:String?=null
    var lsService:String?=null

    companion object {
        lateinit var adapter: NewLeads_Adapter
        lateinit var mItemClick:onItemClickListener
    }


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName = view.findViewById<TextView>(R.id.tvCustomerName)
        val tvLocation = view.findViewById<TextView>(R.id.tvServiceLocation)
        val tvService = view.findViewById<TextView>(R.id.tvServiceAsked)
        val tvDistance=view.findViewById<TextView>(R.id.tvDistance)
        val tvReceivedDate=view.findViewById<TextView>(R.id.tvReceivedDate)
        val ivCall = view.findViewById<ImageView>(R.id.ivCustomerCall)
        val ivMessage = view.findViewById<ImageView>(R.id.ivCustomerMessage)
        val llLeadDetails=view.findViewById<LinearLayout>(R.id.llLeadsDetails)
/*
        val tvView = view.findViewById<TextView>(R.id.tvView)
*/
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent!!.context).inflate(R.layout.new_leads_row_1, parent, false)
        context = parent.context;
        return ViewHolder(view)
        adapter = this
    }


    override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
        holder?.let { holder ->
            lsService = dataSet[position].lsservicename+"  "+dataSet[position].lsservicetypename
            lsLocation = dataSet[position].lsAdd_line1+", "+dataSet[position].lsAdd_line2+", " +dataSet[position].lsCity + ", "+dataSet[position].lsState+", "+dataSet[position].lsPincode
            lsFullname=dataSet[position].lscustomerfirstname+" "+dataSet[position].lscustomerlastname.toString()
            holder.tvName.text = lsFullname
            holder.tvLocation.text = lsLocation
            holder.tvService.text = lsService
            holder.tvDistance.text=dataSet[position].lsdistanceinkm
            var timeStampStr = dataSet[position].lsreceiveddate
            var date = getDate(timeStampStr!!)
            holder.tvReceivedDate.text=date

            holder.ivCall.setOnClickListener(View.OnClickListener {

                if (mItemClick != null) {
                    mItemClick!!.onItemClick(position,holder.ivCall)
                }
            })
            holder.ivMessage.setOnClickListener(View.OnClickListener {

                if (mItemClick != null) {
                    mItemClick!!.onItemClick(position,holder.ivMessage)
                }
            })
            holder.llLeadDetails.setOnClickListener(View.OnClickListener {
                if (mItemClick != null) {
                    mItemClick!!.onItemClick(position,holder.llLeadDetails)
                }
            })
        }
    }

    fun setOnCardClickListener(mItemListener: onItemClickListener) {
        mItemClick = mItemListener
    }
    override fun getItemCount(): Int {
        return this.dataSet.size
    }
    interface onItemClickListener {
        fun onItemClick(position: Int,view: View)

    }

    private fun getDate(timeStampStr: String):String {

        val str = timeStampStr
        val fmt = "yyyy-MM-dd HH:mm:ss"
        val df = SimpleDateFormat(fmt)

        val dt = df.parse(str)

        val tdf = SimpleDateFormat("HH:mm:ss")
        val dfmt = SimpleDateFormat("dd/MM/yyyy")

        val timeOnly = tdf.format(dt)
        val dateOnly = dfmt.format(dt)

        return dateOnly
    }

}



