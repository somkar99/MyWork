package com.example.admin.h2hpartner.UI

import android.app.Activity
import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.example.admin.h2hpartner.BaseActivity
import com.example.admin.h2hpartner.R
import com.example.admin.h2hpartner.Services.TransperantProgressDialog

class Referrals : BaseActivity() {
    override lateinit var context: Context
    override lateinit var activity: Activity
    lateinit var pd: TransperantProgressDialog
    lateinit var llm: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_referrals)
        context = this
        activity = this
    }
}
