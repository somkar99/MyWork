package com.example.admin.h2hpartner.UI

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.GoMobeil.H2H.Extensions.toast
import com.example.admin.h2hpartner.*
import com.example.admin.h2hpartner.Services.StaticRefs
import com.example.admin.h2hpartner.Services.TransperantProgressDialog
import com.github.kittinunf.fuel.Fuel
import com.github.kittinunf.fuel.android.extension.responseJson
import com.sdsmdg.tastytoast.TastyToast
import kotlinx.android.synthetic.main.footer.*
import kotlinx.android.synthetic.main.home.*
import org.json.JSONArray
import org.json.JSONObject

class Home : BaseActivity() {

    override lateinit var context: Context
    override lateinit var activity: Activity
    lateinit var aladdress: ArrayList<String>
    lateinit var data: JSONObject
    var addjson: JSONArray? = null
    var profilestatus: String? = null
    var statusjson: JSONArray? = null
    var kycstatus: String? = null
    var workstatus: String? = null
    var refstatus: String? = null
    var personalstatus: String? = null
    var businesstatus: String? = null
    var pricetatus: String? = null
    var rejectionreason: String? = null
    var lsKey: String? = null
    var lsMessage = ""
    var oncreateflag: Boolean = false
    var approved: Boolean = false
    var rejected: Boolean = false
    lateinit var pd: TransperantProgressDialog
    var firsttime: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)

        activity = this
        context = this
        pd = TransperantProgressDialog(context)

        checkStatus()
        if(prefs.profilestatus.equals(StaticRefs.WAITINGFORAPPROVAL)||prefs.profilestatus.equals(StaticRefs.INCOMPLETE)|| prefs.profilestatus.equals(StaticRefs.REJECTED)){
            ivHome.isEnabled=false
            tvHome.isEnabled=false
        }


    }

    override fun onResume() {
        super.onResume()
        getData()
        initlayout()
        if(firsttime==false){
            pd.show()
            firsttime=true
        }
        tvWelcomeMessage.setText(prefs.fullname)
        tvPrimarybusiness.setText(prefs.pri_business)
        updatecompletionstatus()

    }

    fun initlayout() {
        btnSubmit.setOnClickListener {
            lsMessage = ""
            var lbProceedAhead = true;

            if (prefs.profilestatus.equals(StaticRefs.INCOMPLETE)) {

                if (prefs.personalinfostatus.equals(StaticRefs.INCOMPLETE)) {

                    genMessage("personal information")
                }
                if (prefs.businessinfostatus.equals(StaticRefs.INCOMPLETE)) {

                    genMessage("Business information")
                }
                if (prefs.kycinfostatus.equals(StaticRefs.INCOMPLETE)) {

                    genMessage("KYC information")
                }
                if (prefs.referenceinfostatus.equals(StaticRefs.INCOMPLETE)) {

                    genMessage("Reference information")
                }
                if (prefs.pricinginfostatus.equals(StaticRefs.INCOMPLETE)) {

                    genMessage("Pricing information")
                }

                if (lsMessage.length > 0) {

                    TastyToast.makeText(context, "Please enter  " + lsMessage, Toast.LENGTH_LONG, TastyToast.WARNING).show()
                }


                if (prefs.personalinfostatus.equals(StaticRefs.COMPLETE) && prefs.businessinfostatus.equals(StaticRefs.COMPLETE) && prefs.kycinfostatus.equals(StaticRefs.COMPLETE) && prefs.referenceinfostatus.equals(StaticRefs.COMPLETE) && prefs.pricinginfostatus.equals(StaticRefs.COMPLETE)) {

                    updatestatus()
                }
            }


        }

        linearHomePersonal.setOnClickListener {

            val intent = Intent(this, Personalinfo::class.java)
            intent.putExtra("address", addjson.toString())
            startActivity(intent)


        }

        linearHomeBusiness.setOnClickListener {
            val intent = Intent(this, BusinessInfo::class.java)
            startActivity(intent)

        }

        linearKycDetails.setOnClickListener {
            val intent = Intent(this, KycInfo::class.java)
            startActivity(intent)

        }

        linearHomeworkdocuments.setOnClickListener {

            val intent = Intent(this, Uploadworkimages::class.java)
            startActivity(intent)

        }
        linearHomeReferences.setOnClickListener {

            val intent = Intent(this, ReferencesInfo::class.java)
            startActivity(intent)


        }
        linearHomePricing.setOnClickListener {

            val intent = Intent(this, Pricing::class.java)
            startActivity(intent)

        }
    }

    fun getData() {
        Fuel.post(StaticRefs.VENDORDETAILSURL, listOf((StaticRefs.VENDORID to prefs.vendorid), StaticRefs.TOKEN to prefs.token))
                .timeoutRead(StaticRefs.TIMEOUTREAD)
                .responseJson()
                { request,
                  response,
                  result ->
                    parseJson(result.get().content)


                }
    }

    fun parseJson(response: String) {
        var jsonob: JSONObject? = null
        // data = JSONObject(response).getJSONObject("data")
        val json = JSONObject(response)
        if (response.contains(StaticRefs.DATA) && json.getString(StaticRefs.DATA) != null && !json.getString(StaticRefs.DATA).equals("")) {

            val data1 = json.getString(StaticRefs.DATA)
            val jsondata = JSONObject(data1)
            if (jsondata.length() > 0) {


                val data = json.getJSONObject(StaticRefs.DATA)


                val firstname: String = data.getString(StaticRefs.FIRSTNAME)

                val lastname: String = data.getString(StaticRefs.LASTNAME)
                val mobilenumber: String = data.getString(StaticRefs.VENDORMOBILENO)
                val pribusiness: String = data.getString(StaticRefs.VENDORPRIMARYBUSINESS)
                val businessid: String = data.getString(StaticRefs.BUSINESSID)

                prefs.serviceid = businessid
                //  prefs.serviceid="2"
                prefs.fullname = firstname + " " + lastname
                prefs.mobile_no = mobilenumber
                prefs.pri_business = pribusiness
                prefs.username = data.getString(StaticRefs.USERNAME)
                prefs.gender = data.getString(StaticRefs.GENDER)
                prefs.categroy = data.getString(StaticRefs.CATEGORY)
                prefs.alternateno = data.getString(StaticRefs.ALTMOBILENO)
                prefs.landline = data.getString(StaticRefs.LANDLINE)

                System.out.println("fullname" + prefs.fullname)
                // App.prefs?.dashboard(tvHeaderName, tvHeaderNumber, tvHeaderPribusiness)

                tvWelcomeMessage.setText(prefs.fullname)
                tvPrimarybusiness.setText(prefs.pri_business)
                oncreateflag = true

            } else {
                TastyToast.makeText(context, "No Data Found ", TastyToast.LENGTH_LONG, TastyToast.WARNING).show()

            }

        } else {
            TastyToast.makeText(context, "No Data Found ", TastyToast.LENGTH_LONG, TastyToast.WARNING).show()

        }

    }

    fun genMessage(msg: String) {
        if (lsMessage.length > 0) {
            lsMessage = lsMessage + ", " + msg;
        } else {
            lsMessage = lsMessage + " " + msg;
        }
    }

/*
    fun getProfileStatus() {
        Fuel.post(StaticRefs.VENDORPROFILE, listOf((StaticRefs.VENDORID to prefs.vendorid), StaticRefs.TOKEN to prefs.token))
                .timeoutRead(StaticRefs.TIMEOUTREAD)
                .responseJson()
                { request,
                  response,
                  result ->
                    result.fold({ d ->

                        saveProfilestatus(result.get().content)
                    }, { err ->
                        TastyToast.makeText(context, "Internet Network Down", TastyToast.LENGTH_LONG, TastyToast.ERROR)
                        //do something with error
                    })
                   // saveProfilestatus(result.get().content)


                }

    }
*/

/*
    fun saveProfilestatus(response: String) {

        var jsonob: JSONObject? = null
        // data = JSONObject(response).getJSONObject("data")
        val json = JSONObject(response)

        if (response.contains(StaticRefs.PROFILESTATUS) && json.getString(StaticRefs.PROFILESTATUS) != null) {

            val profilest = json.getString(StaticRefs.PROFILESTATUS)

            profilestatus = json.getString(StaticRefs.PROFILESTATUS)

            prefs.profilestatus = profilestatus
            if (response.contains(StaticRefs.DATA) && json.getString(StaticRefs.DATA) != null && !json.getString(StaticRefs.DATA).equals("")) {


                val data1 = json.getString(StaticRefs.DATA)
                val jsondata = JSONObject(data1)
                if (jsondata.length() > 0) {


                    val data = json.getJSONObject(StaticRefs.DATA)

                    if (profilestatus!!.contains(StaticRefs.REJECTED) && data.has(StaticRefs.PROFILEREJECTIONREASON)) {
                        rejectionreason = data.getString(StaticRefs.PROFILEREJECTIONREASON)
                        btnSubmit.visibility = View.VISIBLE
                    } else if (profilestatus.equals(StaticRefs.INCOMPLETE)) {
                        personalstatus = data.getString(StaticRefs.PERSONALINFOSTATUS)
                        businesstatus = data.getString(StaticRefs.BUSINESSINFOSTATUS)
                        kycstatus = data.getString(StaticRefs.KYCINFOSTATUS)
                        workstatus = data.getString(StaticRefs.WORKIMAGESINFOSTATUS)
                        refstatus = data.getString(StaticRefs.REFERENCESINFOSTATUS)
                        pricetatus = data.getString(StaticRefs.PRICINGINFOSTATUS)
                        prefs.personalinfostatus = personalstatus
                        prefs.businessinfostatus = businesstatus
                        prefs.kycinfostatus = kycstatus
                        prefs.workinfostatus = workstatus
                        prefs.referenceinfostatus = refstatus
                        prefs.pricinginfostatus = pricetatus

                    }

                }
            }


        } else {
            TastyToast.makeText(context, "no Status ", TastyToast.LENGTH_SHORT, TastyToast.ERROR).show()

        }


    }
*/

    fun updatestatus() {
        Fuel.post(StaticRefs.VENDORPROFILEUPDATE, listOf((StaticRefs.VENDORID to prefs.vendorid), StaticRefs.TOKEN to prefs.token))
                .responseJson()
                { request,
                  response,
                  result ->
                    getStatus(result.get().content)

                }

    }

    private fun getStatus(response: String) {

        val json = JSONObject(response)
        if (json.has(StaticRefs.STATUS) && json.getString(StaticRefs.STATUS) != null) {

            var message = ""
            if (json.has(StaticRefs.MESSAGE) && json.getString(StaticRefs.MESSAGE) != null) {

                message = json.getString(StaticRefs.MESSAGE)
            }
            if (json.getString(StaticRefs.STATUS).equals(StaticRefs.FAILED)) {
                val error = json.getString("errors")

                TastyToast.makeText(this, error, Toast.LENGTH_LONG, TastyToast.ERROR).show()


            } else {
                TastyToast.makeText(context, message, Toast.LENGTH_LONG, TastyToast.WARNING).show()
                btnSubmit.visibility = View.GONE
            }


        }
    }

    override fun onBackPressed() {
        if (lsKey.equals(StaticRefs.YES) && !lsKey.equals(null)) {
           super.onBackPressed()
        }

        val popup1 = android.support.v7.app.AlertDialog.Builder(this)
        popup1.setTitle("Closing Application")
                .setMessage("Are you sure you want to Exit")
                .setPositiveButton("YES", DialogInterface.OnClickListener {

                    dialog, which ->
                    // finish()
                    super.onBackPressed()
                })
                .setNegativeButton("No", null)
                .show()


    }

    fun updatecompletionstatus() {

            pd.dismiss()

        if (prefs.profilestatus.equals(StaticRefs.WAITINGFORAPPROVAL)||prefs.profilestatus.equals(StaticRefs.APPROVED)) {
            hideFooter(false)
            linearHomePersonal.setBackgroundResource(R.drawable.personaldone)
            linearHomeBusiness.setBackgroundResource(R.drawable.businessdone)
            linearKycDetails.setBackgroundResource(R.drawable.kycdone)
            if (!(prefs.workinfostatus.equals(StaticRefs.INCOMPLETE))) {
                linearHomeworkdocuments.setBackgroundResource(R.drawable.workdone)
            }
            linearHomeReferences.setBackgroundResource(R.drawable.referencesdone)
            linearHomePricing.setBackgroundResource(R.drawable.pricingdone)
           /* if (prefs.profilestatus.equals(StaticRefs.APPROVED)) {
                if (approved != true) {

                    TastyToast.makeText(context, "Your Profile has been sent for Approval", Toast.LENGTH_LONG, TastyToast.SUCCESS).show()
                    approved = true
                }

                btnSubmit.visibility = View.GONE
                hideFooter(false)


            }*/ if (prefs.profilestatus.contains(StaticRefs.WAITINGFORAPPROVAL)) {
                if (oncreateflag != true) {

                    TastyToast.makeText(context, "Your Profile has been sent for Approval", Toast.LENGTH_LONG, TastyToast.SUCCESS).show()
                    oncreateflag = true
                }

                btnSubmit.visibility = View.GONE


            }

        } else if (prefs.profilestatus.contains(StaticRefs.REJECTED)) {
            if (rejected != true) {

                TastyToast.makeText(context, "Profile is Rejected Reason is" + rejectionreason, Toast.LENGTH_LONG, TastyToast.SUCCESS).show()
                rejected = true
            }
        } else {

            if (prefs.personalinfostatus.equals(StaticRefs.COMPLETE)) {

                linearHomePersonal.setBackgroundResource(R.drawable.personaldone)
            }
            if (prefs.businessinfostatus.equals(StaticRefs.COMPLETE)) {
                linearHomeBusiness.setBackgroundResource(R.drawable.businessdone)

            }
            if (prefs.kycinfostatus.equals(StaticRefs.COMPLETE)) {
                linearKycDetails.setBackgroundResource(R.drawable.kycdone)

            }
            if (prefs.workinfostatus.equals(StaticRefs.COMPLETE)) {
                linearHomeworkdocuments.setBackgroundResource(R.drawable.workdone)

            }
            if (prefs.referenceinfostatus.equals(StaticRefs.COMPLETE)) {
                linearHomeReferences.setBackgroundResource(R.drawable.referencesdone)

            }
            if (prefs.pricinginfostatus.equals(StaticRefs.COMPLETE)) {
                linearHomePricing.setBackgroundResource(R.drawable.pricingdone)

            }
        }


    }

    fun checkStatus() {
        lsKey = getIntent().getStringExtra(StaticRefs.FROMSETTING)

        if (lsKey.equals(StaticRefs.YES) && !lsKey.equals(null)) {
          if(prefs.profilestatus.contains(StaticRefs.APPROVED)){
              tvMessage.setText("Your Profile Is Approved \n Profile Completion 100 %")
          }else if(prefs.profilestatus.contains(StaticRefs.WAITINGFORAPPROVAL)){
              tvMessage.setText("Your Profile has been sent for \n Approval")

          }

            btnSubmit.visibility = View.GONE

            hideFooter(false)
            updatecompletionstatus()
        }

    }


}

